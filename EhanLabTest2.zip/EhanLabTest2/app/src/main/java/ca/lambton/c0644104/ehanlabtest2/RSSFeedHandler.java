package ca.lambton.c0644104.ehanlabtest2;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class RSSFeedHandler extends DefaultHandler {
    private RSSFeed feed; // list of items
    private RSSItem item;
    
    private boolean feedTitleHasBeenRead = false;
    private boolean feedPubDateHasBeenRead = false;

    private boolean isTitle = false;
    private boolean isName = false;
    private boolean isDescription = false;
    private boolean isPrice = false;
    private boolean isCalories = false;
    
    public RSSFeed getFeed() {
        return feed;
    }
        
    public void startDocument() throws SAXException {
        feed = new RSSFeed();
        item = new RSSItem();
    }
    
    public void startElement(String namespaceURI, String localName,
            String qName, Attributes atts) throws SAXException {

        if (qName.startsWith("breakfast")) {
            feed.setTitle(qName);
            isTitle = true;
            return;
        }
        else if (qName.equals("food")) {
            item = new RSSItem();
            return;
        }
        else if (qName.equals("name")) {
            isName = true;
            return;
        }
        else if (qName.equals("description")) {
            isDescription = true;
            return;
        }
        else if (qName.equals("price")) {
            isPrice = true;
            return;
        }
        else if (qName.equals("calories")) {
            isCalories = true;
            return;
        }
    }
    
    public void endElement(String namespaceURI, String localName,
            String qName) throws SAXException
    {
        if (qName.equals("food")) {
            feed.addItem(item);
            return;
        }
    }
     
    public void characters(char ch[], int start, int length)
    {
        String s = new String(ch, start, length);

        if (isName) {
            item.setTitle(s);
            isName = false;
        }
        else if (isPrice) {
            item.setPrice(s);
            isPrice = false;
        }
        else if (isDescription) {
            item.setDescription(s);
            isDescription = false;
        }
        else if (isCalories) {
            item.setCalories(s);
            isCalories = false;
        }        
    }
}