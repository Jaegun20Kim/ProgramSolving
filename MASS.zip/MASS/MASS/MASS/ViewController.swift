//
//  ViewController.swift
//  MASS
//
//  Created by h12 on 2017-03-03.
//  Copyright © 2017 h12. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet var TypeSegment: UISegmentedControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let DestinationScen : MainViewController = segue.destination as! MainViewController
        
        switch TypeSegment.selectedSegmentIndex {
        case 0:
            DestinationScen.FromSegmentIndexOne = "Celsius"
            DestinationScen.FromSegmentIndexTwo = "Fahreheit"
            DestinationScen.ToSegmentIndexOne = "Fahreheit"
            DestinationScen.ToSegmentIndexTwo = "Celsius"
        case 1:
            DestinationScen.FromSegmentIndexOne = "Kilometer"
            DestinationScen.FromSegmentIndexTwo = "Mile"
            DestinationScen.ToSegmentIndexOne = "Mile"
            DestinationScen.ToSegmentIndexTwo = "Kilometer"
            
        case 2:
            DestinationScen.FromSegmentIndexOne = "Kilogram"
            DestinationScen.FromSegmentIndexTwo = "Tonne"
            DestinationScen.ToSegmentIndexOne = "Tonne"
            DestinationScen.ToSegmentIndexTwo = "Kilogram"
            
        case 3:
            DestinationScen.FromSegmentIndexOne = "Megabyte"
            DestinationScen.FromSegmentIndexTwo = "Kilobit"
            DestinationScen.ToSegmentIndexOne = "Kilobit"
            DestinationScen.ToSegmentIndexTwo = "Megabyte"
        
        default:
            break
        }
    }
}

