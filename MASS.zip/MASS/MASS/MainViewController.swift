
import UIKit

class MainViewController: UIViewController {

    @IBOutlet var FromSegment: UISegmentedControl!
    @IBOutlet var ToSegment: UISegmentedControl!
    @IBOutlet var TextField: UITextField!
    @IBOutlet var MainLabel: UILabel!
    
    var FromSegmentIndexOne = String()
    var FromSegmentIndexTwo = String()
    var ToSegmentIndexOne = String()
    var ToSegmentIndexTwo = String()

    override func viewDidLoad() {
        super.viewDidLoad()
        FromSegment.setTitle(FromSegmentIndexOne, forSegmentAt: 0)
        FromSegment.setTitle(FromSegmentIndexTwo, forSegmentAt: 1)
        ToSegment.setTitle(ToSegmentIndexOne, forSegmentAt: 0)
        ToSegment.setTitle(ToSegmentIndexTwo, forSegmentAt: 1)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func Calculate(_ sender: UIButton) {

        if TextField.text == ""{
            MainLabel.text = "Enter Value"
        }
        else{
            if isdouble(Arrayofstrings: TextField.text!){
                
                let answer = performCalculation(From: FromSegment.titleForSegment(at: FromSegment.selectedSegmentIndex)!, To: ToSegment.titleForSegment(at: ToSegment.selectedSegmentIndex)!, TextField: Double(TextField.text!)!)
                MainLabel.text = answer
                
            }
            else{
                MainLabel.text = "Enter valid integer"
            }
        }
        
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
}

func isdouble(Arrayofstrings a:String ...) ->Bool{
    var isdub = true
    for i in a {
        
        let doubcheck:Double? = Double(i)
        if doubcheck == nil{
            isdub = false
        }
    }
    print(isdub)
    return isdub
}
func performCalculation(From f:String, To t:String, TextField num:Double) -> String{
    if f == t{
        return "Don't be dumb:("
    }else if f == "Kilogram" && t == "Tonne"{
        let answer = "\(round(num * 0.001)) \(t)"
        return answer
    }else if f == "Tonne" && t == "Kilogram"{
        let answer = "\(round(num * 1000)) \(t)"
        return answer
    }else if f == "Kilometer" && t == "Mile"{
        let answer = "\(round(num / 1.60934)) \(t)"
        return answer
    }else if f == "Mile" && t == "Kilometer" {
        let answer = "\(round(num * 1.60934)) \(t)"
        return answer
    }else if f == "Celsius" && t == "Fahreheit"{
        let fahrenheit = round(((num * (9/5)) + 32)*100)/100
        let answer = "\(fahrenheit) \(t)"
        return answer
    }else if f == "Fahreheit" && t == "Celsius"{
        let celsius = round(((num - 32)*(5/9))*100)/100
        let answer = "\(celsius) \(t)"
        return answer
    }else if f == "Megabyte" && t == "Kilobit"{
        let fahrenheit = round((num * 1000))
        let answer = "\(fahrenheit) \(t)"
        return answer
    }else if f == "Kilobit" && t == "Megabyte"{
        let celsius = round((num * 0.001))
        let answer = "\(celsius) \(t)"
        return answer
        
    }else{
        return "Boooo"
    }

}
