<?php
ob_start(); // Output Buffer

if (!isset($_SESSION)) {
    session_start();
}

global $connection;

$host = 'localhost';
$user = 'root';
$pass = '';
$db_name = 'crudapp';

$connection = mysqli_connect($host, $user, $pass, $db_name);

if (!$connection) {
    die("CONNECTION TO DB FAILED." . mysqli_error($connection));
} 

?>