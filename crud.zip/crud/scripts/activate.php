<?php 
    global $connection;

    global $update_good, $good_update, $error;

    // 'key' is in insert.php, $user_activation_key
    if (!empty($_GET['key'])) {
        $key = $_GET['key'];
    } else {
        $key = "";
    }


    if($key != '') {
        
        $sql = mysqli_query($connection, "SELECT * FROM signup WHERE activation_key = '{$key}' ");
        
        $count = mysqli_num_rows($sql);
        
        if($count == 1) {
            while ($row = mysqli_fetch_array($sql)) {
                $is_activated = $row['is_activated'];
                
                if ($is_activated == 0) {
                    $update_sql = "UPDATE signup SET is_activated = '1' WHERE activation_key = '{$key}' ";
                    $update_query = mysqli_query($connection, $update_sql);
                    
                    if ($update_query) {
                        $update_good = "<div class='alert alert-danger email_alert'>
                                          <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                                                Your Email Has Been verified Successfully
                                        </div>";                    
                    }
                } else {
                        $good_update = "<div class='alert alert-danger email_alert'>
                                          <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                                                Your Email Has Already Been Verified
                                        </div>"; 
                }
            }
        } else { // $count not equals to 1
            $error = "<div class='alert alert-danger email_alert'>
                        <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                                Error Occured
                      </div>"; 
        }
        
    }
?>