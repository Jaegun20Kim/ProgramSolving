<?php include("./lib/swift_required.php"); ?>




<?php //include("./config/db.php"); ?>   


<?php 

// Include this code until "global $connection" works
//$host = 'localhost';
//$user = 'root';
//$pass = '';
//$db_name = 'crudapp';
//
//$connection = mysqli_connect($host, $user, $pass, $db_name);
//
//if (!$connection) {
//    die("CONNECTION TO DB FAILED." . mysqli_error($connection));
//} 

?>

<?php
    //global $connection;

    global $error1, $error2, $error3, $error4, $error5;
    global $info, $fail;


    // Create some variables
    // Intitialize to empty string
    $f_name = $l_name = $email = $password = "";
    
    // When submit form
    if(isset($_POST['submit'])) {
        $firstname = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        $email = $_POST['email'];
        $pass_word = $_POST['password'];
        
        // Check if email exists
        
        $sql = "SELECT * FROM signup WHERE email = '{$email}' ";
        $sql_query = mysqli_query($connection, $sql);
        $count = mysqli_num_rows($sql_query); 
        
        // Create a salt, could be in MySQL or hardcode it in php.
        
//        $sql_salt = mysqli_query($connection, "SELECT randSaltPass FROM signup");
//        $row = mysqli_fetch_array($sql_salt);
//        $salt = $row['randSaltPass'];
        
        // For now, just hardcode a salt. Will need to change later.
         $salt = '$2a$07$somesillystringforsalt';
        // Encrypt password
        $password = crypt($pass_word, $salt);
        
        
        
        // If these fields are not empty
        if(!empty($firstname) && !empty($lastname) && !empty($email) && !empty($pass_word)) {
            
            if ($count > 0) {
                $error1 = "<div class='alert alert-danger'>
                              <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                                    User With Email Already Exists.
                          </div>";
            } else {
                
                // Clean data before passing
                $f_name = ucwords(mysqli_real_escape_string($connection, $firstname));
                $l_name = ucwords(mysqli_real_escape_string($connection, $lastname));
                $email = mysqli_real_escape_string($connection, $email);
                $password = mysqli_real_escape_string($connection, $password);
                
                // 
                $email_match = filter_var($email, FILTER_VALIDATE_EMAIL);
                if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $error2 = "<div class='alert alert-danger email_alert'>
                              <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                                    Email Is Invalid.
                              </div>";
                }
                
                $f_name_match = preg_match("/^[a-zA-Z]*$/", $f_name);
                if(!preg_match("/^[a-zA-Z]*$/", $f_name)) {
                    $error3 = "<div class='alert alert-danger email_alert'>
                              <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                                    Only Letters Are Allowed For Firstname
                              </div>";
                }
                
                $l_name_match = preg_match("/^[a-zA-Z]*$/", $l_name);
                if(!preg_match("/^[a-zA-Z]*$/", $l_name)) {
                    $error4 = "<div class='alert alert-danger email_alert'>
                              <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                                    Only Letters Are Allowed For Lirstname
                              </div>";
                }
                
//                if(!preg_match()) {
//                    $error5 = "<div class='alert alert-danger email_alert'>
//                              <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
//                                    Password must be 7 - 15 Characters, One Uppercase, One Lowercase 
//                              </div>";        
//                }
                
                
                if ($f_name_match && $l_name_match && $email_match) {
                    //Generate random key
                    $user_activation_key = md5(rand().time());
                    
                    $sql = "INSERT INTO signup (email, firstname, lastname, password, activation_key, is_activated, date_time) VALUES";
                    $sql .= "('{$email}', '{$f_name}', '{$l_name}', '{$password}', '{$user_activation_key}', '0', now())";
                    
                    $query = mysqli_query($connection, $sql);
                    
                    
                    // When query fail
                    if(!$query) {
                        die("QUERY FAILED" . mysqli_error($connection));
                    }
                    
                    // When success, send email
                    if ($query) {
                        
                        $msg = "Please activate your account using this link <a href='http://localhost/crud/user/user_activation.php?key=".$user_activation_key."'>http://localhost/crud/user/user_activation.php?key=".$user_activation_key."</a>";
                        
                        // Create the Transport that call setUsername() and setPassword()
                        $transport = Swift_SmtpTransport::newInstance('smtp.gmail.com', 465, 'ssl')
                        ->setUsername('vzipokemon@gmail.com')
                        ->setPassword('vi100926');

                        $mailer = Swift_Mailer::newInstance($transport);
                        // Create the message
                        $message = Swift_Message::newInstance('Test')
                        // Give the message a subject
                        ->setSubject('Verify Your Email Address')
                        // Set the From address with an associative array
                        ->setFrom(array('vzipokemon@gmail.com' => 'Vincent Test'))
                        // Set the To addresses with an associative array
                        ->setTo(array($email))
                        // Give it a body
                        ->setBody('Body Message')
                        // And optionally an alternative body
                        ->addPart($msg, 'text/html');
                        // Optionally add any attachments
                        $result = $mailer->send($message);
                        
                        if(!$result){
                            $fail = "<div class='alert alert-danger email_alert'>
                                <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times</a>
                                Failed To Send Verification Email.</div>";
                        }else{
                            $info = "<div class='alert alert-info email_alert'>
                                <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times</a>
                                A Verification Email Has been Sent.</div>";
                        }
                        
                        
                        
                        
                        
                        
                        // My version, comment out for archived
                        
                        
//                        $msg = "Please activate your account using this link <a href='http://localhost/crud/user/user_activation.php?key=";
//                        $msg .= $user_activation_key;
//                        $msg .= "'>http://localhost/crud/user/user_activation.php?key=";
//                        $msg .= $user_activation_key."</a>";
//                        
//                        // Create the Transport that call setUsername() and setPassword()
//                        $transport = Swift_SmtpTransport::newInstance('smtp.gmail.com', 465, 'ssl')
//                            ->setUsername('vzipokemon@gmail.com')
//                            ->setPassword('...');
//                        
//                        $mailer = Swift_Mailer::newInstance($transport);
//                        // Create the message
//                        $message = Swift_Message::newInstance('Test')
//                            // Give the message a subject
//                            ->setSubject('Verify Your Email Address')
//                            // Set the From address with an assoc array
//                            ->setFrom(array('workwithvincentzi@gmail.com' => 'Vincent CRUD'))
//                            // Set the To address with an assoc array
//                            ->setTo(array($email))
//                            // Give it a body
//                            ->setBody('Body Message')
//                            // And optionally an alternative body
//                            ->addPart($msg, 'text/html');
//                        
//                        $result = $mailer->send($message); 
//                        
//                        // If fail to send
//                        if (!$result) {
//                            $fail = "<div class='alert alert-danger email_alert'>
//                              <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
//                                    Failed To Send Verification Email
//                              </div>";      
//                        } else {
//                             $info = "<div class='alert alert-danger email_alert'>
//                              <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
//                                    A Verification Email Has Been Sent
//                              </div>";                           
//                        }
                        
                        
                        
                              
                    } 
                    
                }
                
            }
            
          // If these fields are empty
        } else {
            if (empty($firstname)) {
                $error3 = "<div class='alert alert-danger'>
                                <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                                Firstname Field Cannot Be Empty
                           </div>";
            }
            
            if (empty($lastname)) {
                $error4 = "<div class='alert alert-danger'>
                             <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                                Lastname Field Cannot Be Empty
                           </div>";
            }
            
            if (empty($email)) {
                $error2 = "<div class='alert alert-danger'>
                             <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                                Email Field Cannot Be Empty
                           </div>";                
            }
            
            // $pass_word is the raw user input on the signup page
            if (empty($pass_word)) {
                 $error5 = "<div class='alert alert-danger'>
                             <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                                Password Field Cannot Be Empty
                           </div>";               
            }
        } 
            
        //header("Location: " . "signup.php");
    }

?>



