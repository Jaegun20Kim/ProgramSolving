<?php

    global $connection;

//    global $error3, $error4, $error5;

    $error3 = $error4 = $error5 = $error6 = "";

    if (isset($_POST['login'])) {     
        
        $email_login = $_POST['email_login'];
        $password_login = $_POST['password_login']; // Plain text
        
        // Clean data
        $email = filter_var($email_login, FILTER_SANITIZE_EMAIL);
        $pass = mysqli_real_escape_string($connection, $password_login);
        
        // Generate and Execute sql
        $sql_query = "SELECT * FROM signup WHERE email = '{$email_login}' ";
        $query = mysqli_query($connection, $sql_query);
        
        // Get row count
        $count = mysqli_num_rows($query);
        
        if (!$query) {
            die("QUERY FAILED. " . mysqli_error($connection));
        }
        
        // Check if empty
        if (!empty($email_login) && !empty($password_login)) {
            
            if ($count <= 0) {
                     $error3 = "<div class='alert alert-danger email_alert'>
                              <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                                    User Not Found
                              </div>";               
            } else {
                
                while ($row = mysqli_fetch_array($query)) {
                    $id = $row['id'];
                    $firstname = $row['firstname'];
                    $lastname = $row['lastname'];
                    $user_email = $row['email'];
                    $user_password = $row['password']; // Encrpted password
                    $activation_key = $row['activation_key'];
                    $is_activated = $row['is_activated'];
                }
                
                // Encrypted password
                $password = crypt($pass, $user_password);
                
                // Email/Password Match, activated, then login
                if ($is_activated == '1') {
                    if ($email == $user_email && $password == $user_password) {
                    
                      //  header("Location: ./user/home.php");

                        $_SESSION['id'] = $id;
                        $_SESSION['firstname'] = $firstname;
                        $_SESSION['lastname'] = $lastname;
                        $_SESSION['email'] = $email;
                        $_SESSION['activation_key'] = $activation_key;
                        
                        header("Location: ./user/home.php");
                        
                    } else {
                        $error3 = "<div class='alert alert-danger email_alert'>
                                  <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                                        User Not Found
                                  </div>";   
                    }
                } else {
                    $error6 = "<div class='alert alert-danger email_alert'>
                                  <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                                        Sorry, You Have To Verify Your Account Before You Can Login.
                                  </div>";  
                }
                
                
                
                
            }
        } else {
            if (empty($email_login)) {
                $error4 = "<div class='alert alert-danger email_alert'>
                              <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                                    Email Field Cannot Be Empty
                              </div>";   
            }
            
            if (empty($password_login)) {
                $error5 = "<div class='alert alert-danger email_alert'>
                              <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                                    Password Field Cannot Be Empty
                              </div>";   
            }
        }
    }

?>