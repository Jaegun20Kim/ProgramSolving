<?php include("../config/db.php"); ?>


<?php 
    global $connection;
    global $error, $update_good, $fail_update, $empty_update;

    if (isset($_POST['reset'])) {
        
        if (!empty($_GET['key'])) {
            $key = $_GET['key'];
        } else {
            $key = '';
        }
        
        if ($key != '') {
            $pass_word = $_POST['password']; // Plain text
            
            $pass = mysqli_real_escape_string($connection, $pass_word);
            
            $salt_query = mysqli_query($connection, "SELECT randSaltPass FROM signup");
            $row = mysqli_fetch_array($salt_query);
            $salt = $row['randSaltPass'];
            
            $password = crypt($pass,  $salt);
            
            $sql = mysqli_query($connection, "SELECT * FROM signup WHERE activation_key = '{$key}' ");
            $count = mysqli_num_rows($sql);
            
            if (!empty($pass_word)) {
                if ($count == 1) {
                    $update_sql = "UPDATE signup SET password = '{$password}' WHERE activation_key = '{$key}' ";
                    $update_query = mysqli_query($connection, $update_sql);
                    
                    if ($update_query) {
                        $update_good = "<div class='alert alert-success email_alert'>
                                          <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                                                Your Password Reset Has Been verified Successfully
                                        </div>";   
                    }
                    
                } else {
                    
                    $fail_update = "<div class='alert alert-danger email_alert'>
                                          <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                                                No Data Found
                                        </div>";                    
                } 
            } else {
                
                $empty_update = "<div class='alert alert-danger email_alert'>
                                          <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
                                                Password Field Cannot Be Empty
                                        </div>";     
            }
        }
        
        
        
    }
?>