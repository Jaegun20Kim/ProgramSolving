<?php include_once("../config/db.php")?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CRUD APPLICATION - ADMIN DASHBOARD</title>
    
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    
    <!--    Font Awesome Bootstrap CDN-->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    
    <link rel="stylesheet" href="css/admin.css">

</head>

<script>
    $(document).ready(function(){
//This code is written so as to always make the currently selected tab to be active
    
    $('#myTab a').click(function (e) {
        e.preventDefault();
        $(this).tab('show');
        
        //If the current tab is not active, remove every errors if they exist on the page.
        if(("#myTab a") !== $(this)){
            $("#errorFirstname").html("");
            $("#errorLastname").html("");
            $("#errorEmail").html("");
            $("#errorPassword").html("");
            $("#error_Email").html("");
            $("#error_Password").html("");
            $(".alert-danger").remove();
            $(".alert").remove();
            //$(".email_alert").remove();
        }
    });

    // store the currently selected tab in the hash value
    $("ul.nav-tabs > li > a").on("shown.bs.tab", function (e) {
        var id = $(e.target).attr("href").substr(1);
        window.location.hash = id;
    });

    // on load of the page: switch to the currently selected tab
    var hash = window.location.hash;
    $('#myTab a[href="' + hash + '"]').tab('show');
    
    $("#typed_text").typed({
        strings: ["This is a system that allows users to create read update and delete information."],
        typeSpeed: 0
    });

});
</script>

<body>

    <!--   Navigation Bar-->
    <nav class="navbar navbar-inverse" style="border-radius: 0; margin: 0;" >
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span> 
          </button>
          <a class="navbar-brand crud" href="#">CRUD SYSTEM</a>
        </div>
        
<!--        Collect the nav links, forms, and other content for toggling-->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
          
          <ul class="nav navbar-nav navbar-right">
           
            <li class="dash">
                <a href="#"><?php echo $_SESSION['email'] ?></a>
            </li>
            
          </ul>
          
        </div>
        
      </div>
    </nav>

   
<!--    Make sure you know the difference between container and container-fluid-->
    <div class="container-fluid">
        <?php include("index.php") ?>
    </div>


</body>
</html>