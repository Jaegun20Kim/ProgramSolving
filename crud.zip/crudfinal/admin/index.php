<!--Icon Resources: http://fontawesome.io/icons/-->
<?php

function count_values($tbl) {
    global $connection;
    
    $result = mysqli_query($connection, "SELECT * FROM $tbl ");
    $count = mysqli_num_rows($result);
    
    echo "<div style='font-size: 30px;'>{$count}</div>";
}

function count_not_verified_values($tbl) {
    global $connection;
    
    $result = mysqli_query($connection, "SELECT * FROM $tbl WHERE is_activated = '0' ");
    $count = mysqli_num_rows($result);
    
    echo "<div style='font-size: 30px;'>{$count}</div>";
}

?>

<div class="row content">

     <div class="col-md-2 admin-links" style="border: 1px white;">
      <h3 class="text-center">Admin Dashboard</h3>
       <ul>
           <li><a href="dashboard.php"><i class="fa fa-tachometer" aria-hidden="true"></i>Dashboard</a></li>
           <li><a href="./admin_scripts/view.php"><i class="fa fa-user" aria-hidden="true"></i>View All Users</a></li>
           <li><a href="./admin_scripts/verified.php"><i class="fa fa-check" aria-hidden="true"></i>Verified Users</a></li>
           <li><a href="./admin_scripts/not_verified.php"><i class="fa fa-times" aria-hidden="true"></i>Not Verified Users</a></li>
       </ul>
    </div> 

    <div class="col-md-10"> 
        <div class="row rowDiv">
           
            <div class="col-lg-4 col-md-6">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <div class="row">
                           
                            <div class="col-xs-3">
                                <i class="fa fa-user fa-5x"></i>
                            </div>
                            
                            <div class="col-xs-9 text-right" style="color: white;"> 
                                <?php count_values("signup") ?>
                                <div style="font-weight: bold;">Users</div>
                            </div>
                            
                        </div>
                        
                        <a href="./admin_scripts/view.php">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i></span>
                                
<!--                             clearfix class to properly align    -->
                                <div class="clearfix"></div>
                            </div>
                        </a>
                        
                    </div>
                </div>
            </div>
            
            
            <div class="col-lg-4 col-md-6">
                <div class="panel panel-green">
                    <div class="panel-heading">
                        <div class="row">
                           
                            <div class="col-xs-3">
                                <i class="fa fa-check fa-5x font_awesome"></i>
                            </div>
                            
                            <div class="col-xs-9 text-right" style="color: white;">
                               <?php count_values("profile") ?>
                                <div style="font-weight: bold;">Verified Users</div>
                            </div>
                            
                        </div>
                        
                        <a href="./admin_scripts/verified.php">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i></span>
                                
<!--                             clearfix class to properly align    -->
                                <div class="clearfix"></div>
                            </div>
                        </a>
                        
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4 col-md-6">
                <div class="panel panel-red">
                    <div class="panel-heading">
                        <div class="row">
                           
                            <div class="col-xs-3">
                                <i class="fa fa-remove fa-5x font_awesome"></i>
                            </div>
                            
                            <div class="col-xs-9 text-right" style="color: white;">
                                <?php echo count_not_verified_values('signup') ?>
                                <div style="font-weight: bold;">Not Verified Users</div>
                            </div>
                            
                        </div>
                        
                        <a href="./admin_scripts/not_verified.php">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-o-right" aria-hidden="true"></i></span>
                                
<!--                             clearfix class to properly align    -->
                                <div class="clearfix"></div>
                            </div>
                        </a>
                        
                    </div>
                </div>
            </div>
 
        </div>   
    </div>

</div>