<?php
ob_start(); // Turn on Output Buffer

if (!isset($_SESSION)) { //session is already set create new session
    session_start();
}

global $connection;

$host = 'localhost';
$user = 'root';
$pass = '';
$db_name = 'crudapp';

$connection = mysqli_connect($host, $user, $pass, $db_name);

if (!$connection) {
    die("CONNECTION TO DB FAILED." . mysqli_error($connection));
} 





?>