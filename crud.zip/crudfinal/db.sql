-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 10, 2017 at 07:01 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crudapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `id` int(11) NOT NULL,
  `email` varchar(60) NOT NULL DEFAULT 'admin@crud.com',
  `password` varchar(255) NOT NULL DEFAULT 'admin'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`id`, `email`, `password`) VALUES
(1, 'admin@crud.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `appointment_date` varchar(30) NOT NULL,
  `comment` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`id`, `user_id`, `appointment_date`, `comment`) VALUES
(1, 17, '03/01/2017', 'hi'),
(2, 17, '03/23/2017', 'something');

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE `profile` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `firstname` varchar(60) NOT NULL,
  `lastname` varchar(60) NOT NULL,
  `email` varchar(60) NOT NULL,
  `gender` enum('Male','Female') NOT NULL,
  `intro` text NOT NULL,
  `date_time` date NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`id`, `user_id`, `firstname`, `lastname`, `email`, `gender`, `intro`, `date_time`, `image`) VALUES
(4, 17, 'Vincent', 'Su', 'workwithvincentzi@gmail.com', 'Male', 'I am a nice guy', '2017-02-24', 'sample_pic_03.jpg'),
(6, 18, 'Lydia', 'Jiang', 'vincentzimarketing@gmail.com', 'Female', 'OMG', '2017-02-23', 'test_pic_04.jpg'),
(7, 19, 'Jaegun', 'Kim', 'crvjaden@gmail.com', 'Male', 'I am Jaden', '2017-02-24', 'test_pic_05.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `id` int(11) NOT NULL,
  `firstname` varchar(60) NOT NULL,
  `lastname` varchar(60) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `activation_key` varchar(255) NOT NULL,
  `is_activated` enum('0','1') NOT NULL,
  `date_time` date NOT NULL,
  `randSaltPass` varchar(255) NOT NULL DEFAULT '$2a$07$somesillystringforsalt'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`id`, `firstname`, `lastname`, `email`, `password`, `activation_key`, `is_activated`, `date_time`, `randSaltPass`) VALUES
(16, 'Vincentzi', 'Zi', 'abcd@gmail.com', '$2a$07$somesillystringforsaler12Pgo9jHonUQBemk1jTpLiEtYIC9ka', '767453972eff513a00d26679b72cf1c0', '0', '2017-02-22', '$2a$07$somesillystringforsalt'),
(17, 'Mandy', 'Lu', 'workwithvincentzi@gmail.com', '$2a$07$somesillystringforsaleG601XtXF8wB4aXoQtdDdzuLBk8/V/Vi', 'd85672fa306af6a50136a405195dd043', '1', '2017-02-22', '$2a$07$somesillystringforsalt'),
(18, 'Lydia', 'Jiang', 'vincentzimarketing@gmail.com', '$2a$07$somesillystringforsaleG601XtXF8wB4aXoQtdDdzuLBk8/V/Vi', '9c4ff76739d8eccd3822866721aafa07', '1', '2017-02-23', '$2a$07$somesillystringforsalt'),
(19, 'Jaegun', 'Kim', 'crvjaden@gmail.com', '$2a$07$somesillystringforsaleE9iTzqnIanfLryUr1L8DgCzRh8rW8/S', 'e1c7e8413f3502af4c84819b2baf9b74', '1', '2017-02-24', '$2a$07$somesillystringforsalt'),
(20, 'Frank', 'Chen', 'abc@gmail.com', '$2a$07$somesillystringforsalegRkmFqIFqMsApMB0642sl5zSVAsoqHe', '06ce0dda52d76a7e83385edce0b38507', '0', '2017-03-05', '$2a$07$somesillystringforsalt');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_login`
--
ALTER TABLE `admin_login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `profile`
--
ALTER TABLE `profile`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
