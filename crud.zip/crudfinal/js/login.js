$(document).ready(function(){
        
    // Validate Login fields
    $("#log_in").click(function() {  
        
       // e.preventDefault();            
        var email_login = $("#email_login").val();
        var password_login = $("#password_login").val();
        
        var valid_login = true;
        
        if (email_login == "") {
            valid_login = false;
            $("#error_email_login").html("Email login field cannot be empty");
        } else {
            $("#error_email_login").html("");
        }
        
        if (password_login == "") {
            valid_login = false;
            $("#error_password_login").html("Password login field cannot be empty");
        } else {
            $("#error_password_login").html("");
        }
        
        // Ajax request, server side validation and process
        if (valid_login == true) {
            var form_data = {
                email: email_login,
                password: password_login
            };
            
            $.ajax({
                url: "../scripts/login.php",
                type: "POST",
                data: form_data,
                success: function(data) {
                    
                }
            });
        } else {
            return false;
        }         
    });
});
function isEmailValid(emailAddress) {
    return true;
}
function isPasswordValid(string) {
    return true;
}