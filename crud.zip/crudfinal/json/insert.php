<?php include_once("../config/db.php"); ?>
<?php include_once("../lib/swift_required.php"); ?>




<?php
    global $connection;

    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    if (!$connection) {
        die('Connection Failed');
    } else {
        
        //Generate random key
        $user_activation_key = md5(rand().time());

        $query = "INSERT INTO signup (firstname, lastname, email, password, activation_key, is_activated, date_time) VALUES ('{$firstname}','{$lastname}', '{$email}','{$password}', '{$user_activation_key}', '0', now());";
        
        $result = mysqli_query($connection, $query);
        
        if(!$result) {
            die("QUERY FAILED" . mysqli_error($connection));
        }

        // Send activation key 
        if ($result) {
            $msg = "Please activate your account using this link <a href='http://localhost/crud/user/user_activation.php?key=".$user_activation_key."'>http://localhost/crud/user/user_activation.php?key=".$user_activation_key."</a>";
                        
            // Create the Transport that call setUsername() and setPassword()
            $transport = Swift_SmtpTransport::newInstance('smtp.gmail.com', 465, 'ssl')
            ->setUsername('vzipokemon@gmail.com')
            ->setPassword('vi100926');

            $mailer = Swift_Mailer::newInstance($transport);
            // Create the message
            $message = Swift_Message::newInstance('Test')
            // Give the message a subject
            ->setSubject('Verify Your Email Address')
            // Set the From address with an associative array
            ->setFrom(array('vzipokemon@gmail.com' => 'Vincent Test'))
            // Set the To addresses with an associative array
            ->setTo(array($email))
            // Give it a body
            ->setBody('Body Message')
            // And optionally an alternative body
            ->addPart($msg, 'text/html');
            // Optionally add any attachments
            $result = $mailer->send($message);
        }
    }


?>