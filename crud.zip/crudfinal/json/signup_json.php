<?php include_once("../config/db.php"); ?>


    
<?php

global $connection;

$sql = "SELECT * FROM signup";


// An array to accept db records
$records = array();

$result = mysqli_query($connection, $sql);
while ($row = mysqli_fetch_array($result)) {
    $records[] = $row;
}

echo json_encode($records);
    

?>
